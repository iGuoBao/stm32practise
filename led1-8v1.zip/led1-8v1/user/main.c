#include "stm32f10x.h"                  // Device header
#include "LED.h"

int main(void)
{
	LEDinit();
	JLEDinit();
	while(1)
	{
	
	}
}
